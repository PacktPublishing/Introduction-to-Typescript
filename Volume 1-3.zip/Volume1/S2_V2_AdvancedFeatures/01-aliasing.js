function handle(evt) {
}
handle('onclick');
