function handle(evt: 'onclick') {

}

handle('onclick');