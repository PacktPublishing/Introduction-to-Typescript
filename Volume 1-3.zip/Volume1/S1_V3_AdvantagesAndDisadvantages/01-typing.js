var x = 1;

x = x + 1;
x = x + true;
x = x - false;

console.log(x, typeof x);