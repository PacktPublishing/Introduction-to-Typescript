function test(y) {
    return x + y;
}

console.log(test('function'));

x = 'global';

console.log(x);