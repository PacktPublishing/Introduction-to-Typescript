"use strict";
exports.base64encode = function (value) {
    return new Buffer(value).toString('base64');
};
//# sourceMappingURL=base64encoder.js.map