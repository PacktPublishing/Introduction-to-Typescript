export interface IEncoder {
    (value: string): string;
}