import * as OptionsParser from '../OptionsParser';

describe("Encoder", () => {

    it("can be loaded", () => {
        expect(OptionsParser).toBeDefined();
    });

});