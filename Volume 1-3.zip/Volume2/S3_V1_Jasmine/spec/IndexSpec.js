"use strict";
const OptionsParser = require("../OptionsParser");
describe("Encoder", () => {
    it("can be loaded", () => {
        expect(OptionsParser).toBeDefined();
    });
});
//# sourceMappingURL=IndexSpec.js.map