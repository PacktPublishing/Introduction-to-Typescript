"use strict";
exports.TodoStatusComplete = 'complete';
exports.TodoStatusIncomplete = 'incomplete';
