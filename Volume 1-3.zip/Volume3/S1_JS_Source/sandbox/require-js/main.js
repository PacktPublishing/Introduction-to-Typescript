requirejs([ '../../dist/draggabilly.pkgd'], function( Draggabilly ) {
  new Draggabilly('.draggie');
});
