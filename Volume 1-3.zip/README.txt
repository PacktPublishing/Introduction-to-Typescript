To run most course materials:

- Please install Node.js 6.x
- If folder contains package.json, run 'npm install' to install any dependencies
- Typically you can compile the Typescript as specified in the course (tsc -p .) or 'npm run build' where available